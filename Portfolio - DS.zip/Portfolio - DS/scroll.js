function about_me() {
  var about_me = document.getElementById('about_me');
about_me.scrollIntoView({behavior: "smooth"});
}

function project() {
  var about_me = document.getElementById('project');
about_me.scrollIntoView({behavior: "smooth"});
}

function contact() {
  var about_me = document.getElementById('contact');
about_me.scrollIntoView({behavior: "smooth"});
}

